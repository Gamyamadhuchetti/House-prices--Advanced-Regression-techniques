# Advanced-House-price-prediction
# ML-projects
This is a machine learning project which predicts the price of houses.
The entire project is sub classified into segments which follows:
- Exploratory Data Analysis
-Preprocessing of Data
- Handling Missing values
- Finding outliers
- Building a model on the data
- Selecting the best model based on cross validation
- Hyperparameter optimization
- Evaluating the model using evaluation metrics
